package teste;

import modelo.AlunoDao;

public class TesteExcluiPorRa {

	public static void main(String[] args) {
		
		
		AlunoDao alunoDao = new AlunoDao();
		alunoDao.excluiPorRa(2);
		

	}

}
